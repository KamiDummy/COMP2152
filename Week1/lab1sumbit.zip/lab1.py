#Sample Coding Questions 01 Week 01
#Kamus Artur
array = [1,4,7,9]




a, b, c, d = 1, 2, 3, 4

e = ((a - ((b ** c) // d)) + (a % c))

temperature = 32.6
print("The temperature today is: {:.3f} degrees Celsius".format(temperature))
userAge = int(input("Enter your age: ")) + 22
print("Now showing the shop items filtered by age: {}".format(userAge))

